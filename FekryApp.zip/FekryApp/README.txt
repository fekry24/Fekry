طريقة 1: Android Studio
1) افتح Android Studio ثم Open واختر مجلد FekryApp وانتظر المزامنة.
2) Build > Build Bundle(s) / APK(s) > Build APK(s)
3) الملف يظهر في app/build/outputs/apk/debug/app-debug.apk

طريقة 2: بدون تثبيت أي برنامج (GitHub)
1) أنشئ حسابا على github.com وأنشئ مستودعا جديدا (New repository).
2) ارفع محتوى المجلد FekryApp كاملا (بما فيه المجلد المخفي .github).
3) من تبويب Actions شغّل Build APK وبعد دقائق حمّل FEKRY-apk من الأسفل.

التعديل: كل محتوى التطبيق في app/src/main/assets/index.html
(رقم واتساب WA_NUMBER والروابط LINKS والأعمال MEDIA والشركاء PARTNERS).
لصور محلية ضع الملفات في app/src/main/assets/photos واكتب src:'photos/1.jpg'.

package com.fekry.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

public class MainActivity extends Activity {
    private static final String HOME = "file:///android_asset/index.html";
    private WebView web;
    private FrameLayout root;
    private View statusBg;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        root = new FrameLayout(this);
        root.setBackgroundColor(0xFFF4EADB);
        web = new WebView(this);
        web.setBackgroundColor(0xFFF4EADB);
        statusBg = new View(this);
        statusBg.setBackgroundColor(0xFF8B0A12);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        root.addView(statusBg, new FrameLayout.LayoutParams(-1, 0, Gravity.TOP));
        setContentView(root);
        getWindow().setStatusBarColor(0xFF8B0A12);

        // Android 15+ يرسم التطبيق خلف أشرطة النظام: نضيف هوامش بحجمها
        root.setOnApplyWindowInsetsListener((v, i) -> {
            FrameLayout.LayoutParams p = (FrameLayout.LayoutParams) web.getLayoutParams();
            p.setMargins(i.getSystemWindowInsetLeft(), i.getSystemWindowInsetTop(),
                    i.getSystemWindowInsetRight(), i.getSystemWindowInsetBottom());
            web.setLayoutParams(p);
            FrameLayout.LayoutParams s = (FrameLayout.LayoutParams) statusBg.getLayoutParams();
            s.height = i.getSystemWindowInsetTop();
            statusBg.setLayoutParams(s);
            return i;
        });

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (u.toString().startsWith("file:///android_asset/")) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u)); // واتساب، إنستجرام، يوتيوب...
                } catch (Exception ignored) { }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onShowCustomView(View view, CustomViewCallback cb) {
                if (customView != null) { cb.onCustomViewHidden(); return; }
                customView = view;
                customCb = cb;
                root.addView(view, new FrameLayout.LayoutParams(-1, -1));
            }

            @Override
            public void onHideCustomView() {
                if (customView == null) return;
                root.removeView(customView);
                customView = null;
                if (customCb != null) customCb.onCustomViewHidden();
            }
        });

        if (b != null) web.restoreState(b); else web.loadUrl(HOME);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        if (customView != null) { web.getWebChromeClient().onHideCustomView(); return; }
        // يغلق أي نافذة مفتوحة (خدمة، شريك، عارض الأعمال) قبل الرجوع
        web.evaluateJavascript(
            "(function(){var o=document.querySelector('.ov.open,.lb.open');if(o){var b=o.querySelector('.x,#lx');if(b){b.click();return 'y'}}return 'n'})()",
            (ValueCallback<String>) val -> {
                if (val != null && val.contains("y")) return;
                if (web.canGoBack()) web.goBack(); else finish();
            });
    }

    @Override protected void onPause() { super.onPause(); web.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }
}
